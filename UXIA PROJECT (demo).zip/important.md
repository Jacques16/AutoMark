## WE ARE NOT FRONT DEV, WE ARE UXIANS ##
_________________________________________

## LICENCE 
this version is a copyright (c) 2023 - 2024. Free and open source.

## UTILISATION 
Personnal use (because still not stable and verry limited).

## DEV NOTE 
This is just a glimpse of what our future could be like on our new world. Maybe and hopefully over time it will be able to accomplish the unimaginable and push the boundaries of web development.

## CONTACT
Contact me for questions or update ideas :? jacqueslyard@yahoo.fr 